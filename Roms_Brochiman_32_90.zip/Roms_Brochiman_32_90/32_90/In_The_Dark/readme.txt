
░▒▓█▓▒░▒▓███████▓▒░       ░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░      ░▒▓███████▓▒░ ░▒▓██████▓▒░░▒▓███████▓▒░░▒▓█▓▒░░▒▓█▓▒░      
░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░             ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      
░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░             ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      
░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓████████▓▒░▒▓██████▓▒░        ░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓███████▓▒░░▒▓███████▓▒░       
░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░             ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      
░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░             ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      
░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░         ░▒▓█▓▒░   ░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░      ░▒▓███████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      
                                                                                                                                   
                                                                                                                                   

                                                                                                                                   

Jeu pour la GAMEJAM Retro Programmers United for Obscure Systems - Matra Alice session
https://itch.io/jam/rpuos-matra-alice


Cette gamjam m'a fait d�couvrir cette machine que je ne connaissais pas.
J'ai pu apprendre l'assembleur 6803, faire mon premier player musical et surtout me plonger dans la d�couverte du tant redout� EF9345 -)
Il m'aura fallu bien 3 mois pour faire le jeu, malheureusement entre-temps j'ai cass� mon Alice donc je n'ai pas pu faire tout ce que je voulais 
faute de pouvoir tester sur la vraie machine.
Heureusement que j'ai eu des testeurs pour v�rifier si �a fonctionnait avec la cartouche et la cassette.


Ce Jeu est un demake de LARCIN LAZER , avec l'aimable autorisation de son auteur G�raud Zucchini
Le jeu original est disponible ici : https://store.steampowered.com/app/1707400/Larcin_Lazer/


Remerciement � BROCHIMAN et � St�phane Motschwiller pour avoir test� le jeu sur un vrai ALICE suite au d�c�s du mien. 
Remerciement � Daniel Coulon pour l'�mulateur DCALICE 
Remerciement � Olipix pour faire revivre les anciennes machines 
Remerciement � tout ceux qui m'ont aid� sur https://forum.system-cfg.com/


Machine cible : ALICE 32 + 16ko ou ALICE 90

Code : DURUTI   https://duruti.itch.io/
Gfx : PiiiXL   https://piiixl.itch.io/

Programm� en assembleur 6803 en cross plateforme avec DASM et DCAlice 

Lien pour t�l�charger l'�mulateur DCALICE  : http://alice32.free.fr/

Le jeu est compatible avec les versions  2024.03.19 et sup�rieurs

*******************
*   BUT DU JEU    *
*******************

Terminer le niveau en rejoignant la porte et en �vitant les pi�ges.
Attention il faut une bonne m�moire.
Et surtout pensez � prendre les bonus pour pouvoir finir le jeu... 

Pour se d�placer : ZQSD ou Joystick, Sur Emulateur les fl�ches directionnelles sont utilisables �galement
Valider : ESPACE ou FIRE
Revenir � l'�cran titre : BREAK 

AVERTISSEMENT certain joystick peuvent provoquer des d�placements rapide du personnage, il est pr�f�rable de jouer au clavier  


**********************
* POUR LANCER LE JEU *
**********************

L'�mulateur DCALICE est disponible dans le dossier


1 - Cassette 

fichier inTheDark.k7 ou  inTheDark.wav (pour tester sur la machine)

Charger le jeu via la commande CLOADM
Puis une fois charg� lancez le jeu avec RUN 

2 - Cartouche

fichier inTheDark.rom

Sur �mulateur chargez la cartouche puis lancez le jeu avec EXEC 4096 

M�me proc�dure sur un v�ritable ordinateur ALICE
