Tuiles des plus tr�s curieuses
------------------------------

Un jeu pour Matra Alice 32 ou 90.

Le jeu peut-�tre lanc�:
- en mode cartouche gr�ce � l'extension Multiports
- en mode cassette (n�cessite une extension RAM de 16 ko pour l'Alice 32).

Page du projet sur itch.io : https://mokona78.itch.io/tuiles-des-plus-trs-curieuses

Code source du projet : https://gitlab.com/mokona/alicematch3

Versions
--------

1.1 - Ajout d'une version cassette. Ajout d'une jaquette pour cartouche.
1.0 - �cran de fin. Ajustements. 18 niveaux. Manuel complet.
0.9 - Ajout de niveaux, pour un total de 19, avec des contraintes vari�es.
0.8 - Premi�re version publique. Un seul niveau.

